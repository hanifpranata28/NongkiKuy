package com.tugas.NongkiKuy.Api;

public class Api {

    public static String DetailCafe = "192.168.1.9/Cafe/index.php/auth/ApiDetail";
    public static String Cafe = "192.168.1.9/Cafe/index.php/auth/Api";
}
